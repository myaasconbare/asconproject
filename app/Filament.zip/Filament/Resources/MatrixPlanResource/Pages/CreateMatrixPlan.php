<?php

namespace App\Filament\Resources\MatrixPlanResource\Pages;

use App\Filament\Resources\MatrixPlanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMatrixPlan extends CreateRecord
{
    protected static string $resource = MatrixPlanResource::class;
}
