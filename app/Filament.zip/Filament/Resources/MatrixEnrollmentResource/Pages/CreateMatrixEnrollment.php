<?php

namespace App\Filament\Resources\MatrixEnrollmentResource\Pages;

use App\Filament\Resources\MatrixEnrollmentResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMatrixEnrollment extends CreateRecord
{
    protected static string $resource = MatrixEnrollmentResource::class;
}
