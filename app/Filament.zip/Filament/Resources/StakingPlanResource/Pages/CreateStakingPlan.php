<?php

namespace App\Filament\Resources\StakingPlanResource\Pages;

use App\Filament\Resources\StakingPlanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateStakingPlan extends CreateRecord
{
    protected static string $resource = StakingPlanResource::class;
}
