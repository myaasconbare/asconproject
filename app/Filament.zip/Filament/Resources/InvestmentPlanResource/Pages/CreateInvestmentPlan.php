<?php

namespace App\Filament\Resources\InvestmentPlanResource\Pages;

use App\Filament\Resources\InvestmentPlanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateInvestmentPlan extends CreateRecord
{
    protected static string $resource = InvestmentPlanResource::class;
}
