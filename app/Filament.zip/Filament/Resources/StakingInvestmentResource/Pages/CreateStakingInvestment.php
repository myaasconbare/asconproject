<?php

namespace App\Filament\Resources\StakingInvestmentResource\Pages;

use App\Filament\Resources\StakingInvestmentResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateStakingInvestment extends CreateRecord
{
    protected static string $resource = StakingInvestmentResource::class;
}
