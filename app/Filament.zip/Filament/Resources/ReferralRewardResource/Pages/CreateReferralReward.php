<?php

namespace App\Filament\Resources\ReferralRewardResource\Pages;

use App\Filament\Resources\ReferralRewardResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateReferralReward extends CreateRecord
{
    protected static string $resource = ReferralRewardResource::class;
}
