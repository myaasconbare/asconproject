<?php

namespace App\Filament\Resources\CryptoCurrencyResource\Pages;

use App\Filament\Resources\CryptoCurrencyResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCryptoCurrency extends CreateRecord
{
    protected static string $resource = CryptoCurrencyResource::class;
}
