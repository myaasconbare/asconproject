<?php

namespace App\Filament\Resources\TradeDurationResource\Pages;

use App\Filament\Resources\TradeDurationResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTradeDuration extends CreateRecord
{
    protected static string $resource = TradeDurationResource::class;
}
