<?php

namespace App\Filament\Resources\ReferralSettingResource\Pages;

use App\Filament\Resources\ReferralSettingResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateReferralSetting extends CreateRecord
{
    protected static string $resource = ReferralSettingResource::class;
}
