<?php

namespace App\Filament\Resources\InvestmentDeactivationResource\Pages;

use App\Filament\Resources\InvestmentDeactivationResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateInvestmentDeactivation extends CreateRecord
{
    protected static string $resource = InvestmentDeactivationResource::class;
}
