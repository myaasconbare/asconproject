<div>

    <livewire:guest.partials.home-hero-section />

    <livewire:guest.partials.about-section />

    <livewire:guest.partials.process-section />

    <livewire:guest.partials.plans-section />

    <livewire:guest.partials.profit-calculation />

    <livewire:guest.partials.staking-investment />

    <livewire:guest.partials.referral-levels />

    <livewire:guest.partials.currency-section />

    <livewire:guest.partials.crypto-conversions />

    <livewire:guest.partials.service-section />

    <livewire:guest.partials.predictive-section />

    <livewire:guest.partials.faqs-section />

    <livewire:guest.partials.advertise-section />

    <livewire:guest.partials.testimonial-section />

    <livewire:guest.partials.realtime-market />

    <livewire:guest.partials.blog-section />

</div>