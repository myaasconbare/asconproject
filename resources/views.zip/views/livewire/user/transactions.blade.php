<div class="main-content" data-simplebar="">
      <livewire:user.partials.transactions
          title="Transactions"
      />
</div>