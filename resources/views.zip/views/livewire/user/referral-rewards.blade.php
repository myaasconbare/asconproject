<div>
    <livewire:user.partials.matrix-transactions
        :title="$title"
        :commissionType="$commissionType"
    />
</div>