<div align="center" class="text-xs">
    &copy {{ env('APP_NAME') }} {{ date('Y') }}
</div>