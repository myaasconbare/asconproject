<script src="{{ asset('theme/global/js/jquery-3.7.1.min-2.js') }}"></script>
<script src="{{ asset('theme/global/js/bootstrap.bundle.min-2.js') }}"></script>
<script src="{{ asset('theme/global/js/select2.min-2.js') }}"></script>
<script src="{{ asset('theme/global/js/toaster-2.js') }}"></script>
<script src="{{ asset('theme/global/js/swiper-bundle.min-2.js') }}"></script>
<script src="{{ asset('theme/global/js/apexcharts-2.js') }}"></script>
<script src="{{ asset('theme/global/js/datepicker.min-2.js') }}"></script>
<script src="{{ asset('theme/global/js/datepicker.en-2.js') }}"></script>
<script src="{{ asset('theme/frontend/default_theme/js/viewport.jquery-1.js') }}"></script>
<script src="{{ asset('theme/frontend/default_theme/js/aos-1.js') }}"></script>
<script src="{{ asset('theme/frontend/default_theme/js/jquery.fancybox.min-1.js') }}"></script>
<script src="{{ asset('theme/frontend/default_theme/js/odometer.min-1.js') }}"></script>
<script src="{{ asset('theme/frontend/default_theme/js/gsap.min-1.js') }}"></script>
<script src="{{ asset('theme/frontend/default_theme/js/cursor-1.js') }}"></script>
<script src="{{ asset('theme/frontend/default_theme/js/jquery.marquee.min-1.js') }}"></script>
<script src="{{ asset('theme/frontend/default_theme/js/main-1.js') }}"></script>

<script>
    "use strict";

    function notify(status, message) {
        toastr[status](message);
    }
</script> 